package FoodOrderingSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FoodOrderingSystem extends JFrame {

    private JCheckBox cPizza, cBurger, cFries, cSoftDrinks, cTea, cSundae;

    private JRadioButton rb5, rb10, rb15, rbNone;
    private JButton btnOrder;

    public FoodOrderingSystem() {
        setTitle("Food Ordering System");



        ButtonGroup discountGroup = new ButtonGroup();
        discountGroup.add(rb5);
        discountGroup.add(rb10);
        discountGroup.add(rb15);
        discountGroup.add(rbNone);

        JButton btnOrder = new JButton("Order");

        setLayout(new GridLayout(5, 1));
        add(cPizza);
        add(cBurger);
        add(cFries);
        add(cSoftDrinks);
        add(cTea);
        add(cSundae);

        add(rb5);
        add(rb10);
        add(rb15);
        add(rbNone);
        add(btnOrder);

        btnOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double total = calculateTotal();
                double discount = calculateDiscount(total);
                double finalPrice = total - discount;

                JOptionPane.showMessageDialog(
                        null,
                        String.format("The total price is Php %.2f", finalPrice),
                        "Order Total",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }
        });

        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private double calculateTotal() {
        double total = 0;
        double pizzaPrice = 100;
        if (cPizza.isSelected()) total += pizzaPrice;
        double burgerPrice = 80;
        if (cBurger.isSelected()) total += burgerPrice;
        double friesPrice = 65;
        if (cFries.isSelected()) total += friesPrice;
        double softDrinksPrice = 55;
        if (cSoftDrinks.isSelected()) total += softDrinksPrice;
        double teaPrice = 50;
        if (cTea.isSelected()) total += teaPrice;
        double sundaePrice = 40;
        if (cSundae.isSelected()) total += sundaePrice;
        return total;
    }

    private double calculateDiscount(double total) {
        if (rb5.isSelected()) return total * 0.05;
        else if (rb10.isSelected()) return total * 0.10;
        else if (rb15.isSelected()) return total * 0.15;
        return 0;
    }

    public static void main(String[] args) {
        new FoodOrderingSystem();
    }
}